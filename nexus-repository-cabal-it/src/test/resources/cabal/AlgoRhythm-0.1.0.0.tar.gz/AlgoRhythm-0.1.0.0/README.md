1. `stack setup`
2. `stack build`
3. `stack exec music-exe` or `stack test`
